# WebGenix Landing Page - UI Documentation

## Overview
Premium, modern landing page for WebGenix web development services. Features dark/light theme toggle, 8 service offerings, pricing tables, and conversion-optimized design.

---

## File Structure
```
landing-page/
├── index.html              # Main landing page
├── style.css               # Complete styling (1196 lines)
├── script.js               # Interactive functionality
├── services-data.js        # All dynamic content data
├── upcoming-projects.html  # Projects page
└── services/
    ├── startup-website.html
    ├── business-growth.html
    ├── ecommerce-store.html
    ├── custom-web-app.html
    ├── managed-hosting.html
    ├── seo-growth.html
    ├── enterprise-saas.html
    └── dedicated-team.html
```

---

## Design System

### Color Palette
```css
/* Dark Theme (Default) */
--color-bg: #0a0a0a           /* Deep black background */
--color-bg-alt: #111111         /* Slightly lighter black */
--color-surface: #1a1a1a       /* Card/component background */
--color-text: #fafafa           /* Primary white text */
--color-text-secondary: #a1a1a1 /* Muted gray text */
--color-text-muted: #525252     /* Very muted text */

/* Brand Colors */
--color-primary: #3b82f6         /* Blue */
--color-primary-hover: #2563eb   /* Darker blue */
--color-accent: #8b5cf6          /* Purple */
--color-success: #22c55e          /* Green */

/* Light Theme */
--color-bg: #ffffff
--color-bg-alt: #f8f9fa
--color-surface: #ffffff
--color-text: #1a1a1a
--color-text-secondary: #666666
--color-text-muted: #999999
```

### Typography
```css
--font-main: 'Inter', system-ui, -apple-system, sans-serif
--font-display: 'Space Grotesk', system-ui, sans-serif
```

### Spacing & Sizing
```css
--container-max-width: 1200px
--radius-sm: 6px
--radius-md: 10px
--radius-lg: 16px
--radius-full: 9999px
```

---

## Component Documentation

### 1. Announcement Bar
**Location**: Top of page, above header  
**Purpose**: Promote 20% student/startup discount

```html
<div class="announcement-bar">
    <span class="icon">🎓</span>
    <span>20% off for students & startups. <a href="#contact">Claim now →</a></span>
</div>
```

**Styling**:
- Max-width: 640px, centered
- Background: `rgba(34, 197, 94, 0.08)` (light green tint)
- Border: `rgba(34, 197, 94, 0.15)`
- Border-radius: 9999px (pill shape)
- Font-size: 0.85rem
- Responsive: Max-width 90% on mobile

---

### 2. Premium Navbar
**Location**: Sticky top navigation  
**Key Features**: Glassmorphism, slim design, theme toggle

#### HTML Structure
```html
<header class="header" id="header">
    <div class="container">
        <div class="header-content">
            <a href="#" class="logo">...</a>
            <nav class="nav" id="nav">...</nav>
            <div class="header-actions">
                <button class="theme-toggle" id="themeToggle">...</button>
                <a href="#contact" class="btn btn-primary">Start Project</a>
            </div>
            <button class="mobile-menu-btn">...</button>
        </div>
    </div>
</header>
```

#### CSS Properties
```css
.header {
    position: sticky;
    top: 0;
    z-index: 100;
    padding: 12px 0;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    box-shadow: 0 2px 24px rgba(0, 0, 0, 0.04);
    border-bottom: 1px solid rgba(0, 0, 0, 0.04);
}
```

#### Logo Component
- Icon: 32px square, gradient background (`--color-primary` to `--color-accent`)
- Text: 1.2rem, font-weight 600, letter-spacing -0.02em
- Hover: Icon scales 1.05x

#### Navigation Links
- Gap: 36px between links
- Font-weight: 500, font-size: 0.95rem
- Color: `var(--color-text-secondary)`
- Hover: Color changes to primary, animated underline appears (scaleX transition)

#### Theme Toggle
- Size: 36px square, border-radius: 8px
- Ghost button style with subtle border
- Icons: ☀️ (light), 🌙 (dark)
- Smooth 400ms transition between states

#### CTA Button ("Start Project")
- Gradient: `linear-gradient(135deg, var(--color-primary), var(--color-accent))`
- Border-radius: 9999px (pill shape)
- Padding: 10px 28px
- Hover: Lift effect (-2px), enhanced shadow

---

### 3. Hero Section
**Purpose**: Primary value proposition and conversion point

#### Layout
```html
<section class="hero" id="hero">
    <div class="hero-pattern"></div>  <!-- Decorative background -->
    <div class="container">
        <div class="hero-content">
            <div class="hero-badge">Available for new projects</div>
            <h1 class="hero-title">Building <span class="text-gradient">Modern Websites</span> That Work</h1>
            <p class="hero-description">We build awesome websites...</p>
            <div class="hero-actions">
                <a href="#services" class="btn btn-primary">Explore Services</a>
                <a href="#contact" class="btn btn-secondary">Let's Talk</a>
            </div>
            <div class="hero-stats">...</div>
        </div>
    </div>
</section>
```

#### Styling
- Min-height: 90vh, centered content
- Background pattern: Radial gradients with primary/accent colors at 8% opacity
- Title: 3.5rem, font-weight 800, line-height 1.1
- Gradient text: `linear-gradient(135deg, #3b82f6, #8b5cf6)`

#### Stats Counter
- 3 items: Projects Done (6), Dedication (100%), Available (24/7)
- Animated number counters (JavaScript-driven)
- Separator: 1px vertical line

---

### 4. Marquee Section
**Purpose**: Tech stack showcase with infinite scroll

```html
<section class="marquee-section">
    <div class="marquee">
        <div class="marquee-content">
            <span>HTML5</span><span>CSS3</span>... (repeated 2x)
        </div>
    </div>
</section>
```

**Animation**: CSS `@keyframes marquee` - translates content 50% left over 25s, infinite linear loop

---

### 5. Services Section
**Purpose**: Display 8 service offerings in grid layout

#### Data Source
Dynamic from `services-data.js`:
```javascript
services: [
    { icon: "🚀", title: "Startup Website", description: "...", features: [...] },
    // ... 7 more services
]
```

#### Rendering (script.js)
```javascript
function renderServices() {
    container.innerHTML = servicesData.services.map(service => `
        <div class="service-card animate-on-scroll">
            <div class="service-icon">${service.icon}</div>
            <h3 class="service-title">${service.title}</h3>
            <p class="service-desc">${service.description}</p>
            <ul class="service-features">...</ul>
        </div>
    `).join('');
}
```

#### Grid Layout
```css
.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
}
```

#### Card Styling
- Background: `var(--color-surface)`
- Border: `1px solid rgba(255, 255, 255, 0.05)`
- Border-radius: 16px
- Padding: 24px
- Hover: Lift (-5px), border color change to primary with 20% opacity

---

### 6. Process Section
**Layout**: 4-step horizontal timeline

```html
<div class="process-grid">
    <div class="process-step">
        <div class="step-number">01</div>
        <div class="step-icon">💬</div>
        <h3 class="step-title">Let's Chat</h3>
        <p class="step-desc">...</p>
    </div>
    <!-- Steps 02-04 -->
</div>
```

**Grid**: `repeat(auto-fit, minmax(200px, 1fr))`  
**Step Numbers**: 2.5rem, font-weight 800, accent color at 30% opacity

---

### 7. Pricing Section
**Purpose**: 8 pricing cards with conversion-optimized pricing

#### Updated Pricing (2026)
| Service | Price | Period |
|---------|-------|--------|
| Startup Website | ₹5,999+ | /starting project |
| Business Growth | ₹11,999+ | /starting project |
| E-Commerce Store | ₹17,999+ | /starting project |
| Custom Web App | ₹49,999+ | /starting project |
| Managed Hosting | ₹499+ | /month |
| SEO & Growth | ₹2,999+ | /month |
| Enterprise SaaS | ₹99,999+ | /custom quote |
| Dedicated Dev Team | ₹24,999+ | /month per developer |

#### Card Structure
```html
<div class="pricing-card featured">
    <div class="pricing-badge">Popular for SMEs</div>
    <h3 class="pricing-name">Business Growth Website</h3>
    <div class="pricing-price">
        <span class="pricing-amount">₹11,999+</span>
    </div>
    <div class="pricing-period">/starting project</div>
    <ul class="pricing-features">...</ul>
    <a href="services/..." class="btn">View Details</a>
</div>
```

#### Featured Card
- Additional class: `featured`
- Border color: `rgba(139, 92, 246, 0.3)`
- Background: Gradient from surface to accent at 5% opacity
- Badge: Positioned absolute, gradient background

---

### 8. FAQ Section
**Interactive**: Click to expand/collapse answers

```javascript
function setupFAQToggle() {
    faqItems.forEach(item => {
        question.addEventListener('click', function() {
            // Toggle 'active' class
            // CSS handles max-height animation
        });
    });
}
```

**Animation**: `max-height: 0 → 200px` with 350ms ease transition

---

### 9. CTA Section
**Purpose**: Final conversion point before contact

```html
<section class="section cta-section">
    <h2 class="cta-title">Ready to Build Your <span class="text-gradient">Online Presence</span>?</h2>
    <p class="cta-desc">Let's work together...</p>
    <a href="#contact" class="btn btn-primary btn-lg">
        Start Your Project →
    </a>
</section>
```

---

### 10. Contact Section
**Layout**: 2-column (Contact Info + Form)

#### Contact Information Cards
- Email: `webgenix.host.cloud@gmail.com`
- WhatsApp: `+91 9990230479`
- Address: `Noida, Sector 46`
- Response Time: `Within 24 hours`
- Student Discount: `20% off for verified students!`

#### Contact Form
**Action**: `https://formsubmit.co/webgenix.host.cloud@gmail.com`  
**Method**: POST  
**Hidden Fields**:
```html
<input type="hidden" name="_subject" value="New WebGenix Inquiry">
<input type="hidden" name="_captcha" value="false">
<input type="hidden" name="_template" value="table">
```

**Fields**:
1. Name (text, required)
2. Email (email, required)
3. Service Needed (dropdown)
4. Budget (dropdown, optional)
5. Project Details (textarea)

---

### 11. Footer
**Structure**: 3-column layout (Brand + Services Links + Connect Links)

```html
<footer class="footer">
    <div class="footer-top">
        <div class="footer-brand">
            <div class="logo">...</div>
            <p>Helping startups and small businesses...</p>
        </div>
        <div class="footer-links">...</div>
        <div class="footer-links">...</div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2026 WebGenix. Built with ❤️ by a vibe coder.</p>
        <div class="footer-social">...</div>
    </div>
</footer>
```

---

## Service Detail Pages (8 Total)

### Common Structure (Each Page)
1. **2-Column Hero**: Text left, browser mockup right
2. **Trust Bar**: 5 key highlights in horizontal row
3. **Core Features**: 6-card grid with icons
4. **Add-On Features**: 6-card grid (section-alt background)
5. **Process Timeline**: 4-step numbered cards
6. **Live Preview**: 3 preview cards with images
7. **Benefits**: 6-card grid with green accent borders
8. **FAQ**: 6 accordion items
9. **CTA Banner**: Full-width gradient banner

### Page-Specific Pricing
| Page | Price |
|------|-------|
| startup-website.html | ₹5,999+ |
| business-growth.html | ₹11,999+ |
| ecommerce-store.html | ₹17,999+ |
| custom-web-app.html | ₹49,999+ |
| managed-hosting.html | ₹499+ |
| seo-growth.html | ₹2,999+ |
| enterprise-saas.html | ₹99,999+ |
| dedicated-team.html | ₹24,999+ |

---

## JavaScript Functionality

### Theme Toggle
```javascript
function setupThemeToggle() {
    const savedTheme = localStorage.getItem('webgenix-theme') || 'dark';
    html.setAttribute('data-theme', savedTheme);
    
    themeToggle.addEventListener('click', function() {
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', newTheme);
        localStorage.setItem('webgenix-theme', newTheme);
    });
}
```

### Scroll Animations
- Elements with class `animate-on-scroll` start invisible (opacity: 0, translateY: 20px)
- IntersectionObserver adds class `visible` when element enters viewport
- Transition: 0.7s ease

### Number Counters
- Elements with `[data-target]` attribute
- Animates from 0 to target value over ~1 second
- Triggered when element scrolls into view

### Smooth Scroll
- Intercepts all `href^="#"` links
- Calculates target position minus 70px header offset
- Uses `window.scrollTo({ behavior: 'smooth' })`

---

## Responsive Breakpoints

### Desktop (> 1024px)
- Full 3-column footer
- 2-column contact section
- Multi-column grids (services, pricing, etc.)

### Tablet (768px - 1024px)
- 2-column footer
- Single-column contact section
- Grids adjust to `minmax(240px, 1fr)`

### Mobile (< 768px)
- Hamburger menu (`.mobile-menu-btn`)
- Stacked layout (all single column)
- Font sizes reduced (hero title: 2.5rem → 2rem)
- Nav links hidden by default, shown with `.active` class
- Announcement bar: 90% width, smaller padding

---

## Form Submission

### Contact Form (Landing Page)
**Service**: [FormSubmit.co](https://formsubmit.co/)  
**Email Destination**: `webgenix.host.cloud@gmail.com`  
**Activation**: First submission sends confirmation email to recipient

**Flow**:
1. User fills form
2. FormSubmit processes data
3. Email sent to `webgenix.host.cloud@gmail.com`
4. User redirected back (or stays on page)

---

## Upcoming Projects Page

**File**: `upcoming-projects.html`  
**Purpose**: Showcase future projects with progress tracking

### Sections
1. Hero with "Coming Soon" badge
2. Project cards (6 total) with status badges
3. Progress bars showing development status
4. Newsletter subscription form

### Project Status
| Project | Progress |
|---------|----------|
| Web File Manager Pro | 75% |
| Web-Based SSH Portal | 45% |
| SaaS Dashboard Template | 20% |
| AI Content Generator | 10% |
| Business Analytics Suite | 5% |
| E-Commerce Platform | 5% |

---

## Performance Optimizations

1. **CSS Animations**: GPU-accelerated transforms (translateY) instead of top/left
2. **Intersection Observer**: Efficient scroll-based animations
3. **Font Loading**: `rel="preconnect"` for Google Fonts
4. **Glassmorphism**: backdrop-filter for modern blur effects
5. **CSS Variables**: Single source of truth for theming
6. **Minimal JS**: Only essential interactivity, no heavy frameworks

---

## Browser Support

- **Modern Browsers**: Chrome, Firefox, Safari, Edge (last 2 versions)
- **backdrop-filter**: Requires -webkit- prefix for Safari
- **CSS Grid**: Fully supported in modern browsers
- **IntersectionObserver**: Polyfill not included (modern browsers only)
- **localStorage**: Required for theme persistence

---

## Key Conversion Elements

1. **Sticky CTA**: "Start Project" button always visible in navbar
2. **Pricing**: Single attractive price with "+" (no range confusion)
3. **Trust Signals**: Stats counter, testimonials, process transparency
4. **Multiple CTAs**: Hero, pricing cards, CTA section, contact form
5. **Urgency**: "20% off for students & startups" announcement
6. **FormSimplicity**: Minimal fields, clear labeling
7. **Mobile Optimization**: Fully responsive with touch-friendly buttons

---

## Contact Information (Displayed)

- **Email**: webgenix.host.cloud@gmail.com
- **WhatsApp**: +91 9990230479
- **Address**: Noida, Sector 46
- **Response Time**: Within 24 hours (usually faster!)

---

## Last Updated
May 5, 2026
